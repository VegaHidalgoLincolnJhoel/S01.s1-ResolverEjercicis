/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana_1;

public class areaTriangulo {
    public static void main(String[] args) {
        final int base = 194;
        final int altura = 207;
        int area;
        
        area = (base * altura)/2;
        
        System.out.println("El area del trinagulo es: " + area);
    }
}
