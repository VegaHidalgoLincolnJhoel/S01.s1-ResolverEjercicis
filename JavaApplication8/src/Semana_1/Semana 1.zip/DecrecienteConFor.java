/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana_1;

public class DecrecienteConFor {

    public static void main(String[] args) {
        int numero = 40;

        for (int i = numero; i >= 1; i--) {
            System.out.print(i + " ");
        }
    }
}
