/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Semana_1;

public class DecrecienteConWhile {

    public static void main(String[] args) {
        int numero = 10;

        int i = numero;
        while (i >= 1) {
            System.out.print(i + " ");
            i--;
        }
    }
}
